import Vue from 'vue'
import Tawk from 'vue-tawk'

Vue.use(Tawk, {
  tawkSrc: 'https://embed.tawk.to/5df830ead96992700fcc97d1/default'
})
