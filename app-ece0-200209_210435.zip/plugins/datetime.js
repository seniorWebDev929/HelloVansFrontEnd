import Vue from 'vue'
import Datetime from 'vue-datetime'

Vue.use(Datetime)
