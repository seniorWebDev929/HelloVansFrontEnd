import Vue from 'vue'

import StarRating from 'vue-star-rating'

Vue.component('star-vote', StarRating)
