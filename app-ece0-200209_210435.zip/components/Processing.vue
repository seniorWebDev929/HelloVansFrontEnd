<template>
  <b-modal
    id="processing"
    :hide-header="true"
    :hide-footer="true"
    centered
    no-close-on-backdrop
  >
    <div class="loader">Processing...</div>
  </b-modal>
</template>
