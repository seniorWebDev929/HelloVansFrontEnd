import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _00c5b856 = () => interopDefault(import('..\\pages\\area-we-cover.vue' /* webpackChunkName: "pages_area-we-cover" */))
const _18b616d0 = () => interopDefault(import('..\\pages\\checkout.vue' /* webpackChunkName: "pages_checkout" */))
const _754a4084 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages_contact" */))
const _b6505bd2 = () => interopDefault(import('..\\pages\\driver-terms-and-conditions.vue' /* webpackChunkName: "pages_driver-terms-and-conditions" */))
const _3772bf81 = () => interopDefault(import('..\\pages\\driver-tutorial.vue' /* webpackChunkName: "pages_driver-tutorial" */))
const _88436298 = () => interopDefault(import('..\\pages\\faq.vue' /* webpackChunkName: "pages_faq" */))
const _674d0d23 = () => interopDefault(import('..\\pages\\forgot-password.vue' /* webpackChunkName: "pages_forgot-password" */))
const _8ee12ff2 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _4fd0a3f5 = () => interopDefault(import('..\\pages\\my-jobs.vue' /* webpackChunkName: "pages_my-jobs" */))
const _ae606420 = () => interopDefault(import('..\\pages\\my-move.vue' /* webpackChunkName: "pages_my-move" */))
const _c28c0a54 = () => interopDefault(import('..\\pages\\my-quotes.vue' /* webpackChunkName: "pages_my-quotes" */))
const _71658669 = () => interopDefault(import('..\\pages\\privacy-policy.vue' /* webpackChunkName: "pages_privacy-policy" */))
const _64fb4e72 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages_profile" */))
const _36abdf75 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */))
const _d0ab9a26 = () => interopDefault(import('..\\pages\\reset.vue' /* webpackChunkName: "pages_reset" */))
const _44882aec = () => interopDefault(import('..\\pages\\size-calculator.vue' /* webpackChunkName: "pages_size-calculator" */))
const _5efa6a74 = () => interopDefault(import('..\\pages\\terms-and-conditions.vue' /* webpackChunkName: "pages_terms-and-conditions" */))
const _7e7bf2a0 = () => interopDefault(import('..\\pages\\tutorial.vue' /* webpackChunkName: "pages_tutorial" */))
const _2d962050 = () => interopDefault(import('..\\pages\\driver\\jobs.vue' /* webpackChunkName: "pages_driver_jobs" */))
const _39419724 = () => interopDefault(import('..\\pages\\driver\\join.vue' /* webpackChunkName: "pages_driver_join" */))
const _268e6048 = () => interopDefault(import('..\\pages\\driver\\my-base.vue' /* webpackChunkName: "pages_driver_my-base" */))
const _22307620 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _5b136218 = () => interopDefault(import('..\\pages\\_landing\\index.vue' /* webpackChunkName: "pages__landing_index" */))
const _595cc0d0 = () => interopDefault(import('..\\pages\\_landing\\_slug.vue' /* webpackChunkName: "pages__landing__slug" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/area-we-cover",
    component: _00c5b856,
    name: "area-we-cover"
  }, {
    path: "/checkout",
    component: _18b616d0,
    name: "checkout"
  }, {
    path: "/contact",
    component: _754a4084,
    name: "contact"
  }, {
    path: "/driver-terms-and-conditions",
    component: _b6505bd2,
    name: "driver-terms-and-conditions"
  }, {
    path: "/driver-tutorial",
    component: _3772bf81,
    name: "driver-tutorial"
  }, {
    path: "/faq",
    component: _88436298,
    name: "faq"
  }, {
    path: "/forgot-password",
    component: _674d0d23,
    name: "forgot-password"
  }, {
    path: "/login",
    component: _8ee12ff2,
    name: "login"
  }, {
    path: "/my-jobs",
    component: _4fd0a3f5,
    name: "my-jobs"
  }, {
    path: "/my-move",
    component: _ae606420,
    name: "my-move"
  }, {
    path: "/my-quotes",
    component: _c28c0a54,
    name: "my-quotes"
  }, {
    path: "/privacy-policy",
    component: _71658669,
    name: "privacy-policy"
  }, {
    path: "/profile",
    component: _64fb4e72,
    name: "profile"
  }, {
    path: "/register",
    component: _36abdf75,
    name: "register"
  }, {
    path: "/reset",
    component: _d0ab9a26,
    name: "reset"
  }, {
    path: "/size-calculator",
    component: _44882aec,
    name: "size-calculator"
  }, {
    path: "/terms-and-conditions",
    component: _5efa6a74,
    name: "terms-and-conditions"
  }, {
    path: "/tutorial",
    component: _7e7bf2a0,
    name: "tutorial"
  }, {
    path: "/driver/jobs",
    component: _2d962050,
    name: "driver-jobs"
  }, {
    path: "/driver/join",
    component: _39419724,
    name: "driver-join"
  }, {
    path: "/driver/my-base",
    component: _268e6048,
    name: "driver-my-base"
  }, {
    path: "/",
    component: _22307620,
    name: "index"
  }, {
    path: "/:landing",
    component: _5b136218,
    name: "landing"
  }, {
    path: "/:landing/:slug",
    component: _595cc0d0,
    name: "landing-slug"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
