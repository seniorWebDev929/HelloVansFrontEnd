<template>
  <div class="container section_mod-2">
    <h2 class="ui-title-block">Register</h2>
    <div class="border-color border-color_default"></div>
    <RegisterForm />
  </div>
</template>

<script>
import RegisterForm from '~/components/RegisterForm.vue'

export default {
  middleware: ['guest'],
  components: {
    RegisterForm
  },
  head() {
    return {
      title:
        'Register | Compare low cost Man with a van quotes - book Man and van for Removals',
      meta: [
        {
          hid: 'description',
          name: 'description',
          content:
            'Register  | Compare low cost Man with a van quotes - book Man and van for Removals'
        }
      ]
    }
  }
}
</script>
